﻿(ns clojure.testprotocol)

(defprotocol P1 (m1 [x]))

